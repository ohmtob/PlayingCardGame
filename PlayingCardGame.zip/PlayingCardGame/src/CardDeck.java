public interface CardDeck
{
    void playGame(int numberOfPlayers);

    void displayWinners();


}