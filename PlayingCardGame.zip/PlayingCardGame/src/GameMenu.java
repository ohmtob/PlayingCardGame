public abstract class GameMenu implements CardDeck {


    public static void displayMenu() {
        System.out.println( "" );
        System.out.println( "Welcome to my card game" );
        System.out.println( "" );
        System.out.println( "\t -MENU-" );
        System.out.println( "1. Play game" );
        System.out.println( "2. Show rules" );
        System.out.println( "3. End game" );
        System.out.println( "" );
        System.out.println( "Enter 1-3: " );
    }
}
