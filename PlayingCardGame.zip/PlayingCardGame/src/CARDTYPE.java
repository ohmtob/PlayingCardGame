public enum CARDTYPE {
    CLUB, DIAMOND, HEARTS, SPADE;

}
